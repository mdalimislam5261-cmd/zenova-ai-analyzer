package com.zenova.analyzer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("zenova", MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var signal: TextView
    private lateinit var stats: TextView
    private lateinit var historyBox: LinearLayout
    private lateinit var roundInput: EditText
    private lateinit var outcome: Spinner
    private val bg = Color.rgb(12, 8, 22)
    private val card = Color.rgb(28, 19, 44)
    private val purple = Color.rgb(157, 105, 255)
    private val cyan = Color.rgb(75, 228, 239)
    private val white = Color.rgb(247, 243, 255)
    private val muted = Color.rgb(178, 164, 198)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 28, 18, 24)
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("ZENOVA  AI", 25f, cyan, true))
        root.addView(text("BIG / SMALL • MARKET ANALYZER", 12f, muted, true).apply {
            setPadding(0, 4, 0, 18)
        })

        val hero = panel()
        hero.addView(text("CURRENT ANALYSIS", 11f, cyan, true))
        signal = text("WAIT", 36f, white, true).apply { setPadding(0, 8, 0, 2) }
        hero.addView(signal)
        status = text("প্রথমে ফলাফল যোগ করুন", 13f, muted, false)
        hero.addView(status)
        stats = text("মোট ০ • BIG ০ • SMALL ০", 13f, white, true).apply { setPadding(0, 14, 0, 0) }
        hero.addView(stats)
        root.addView(hero)

        val addPanel = panel()
        addPanel.addView(text("ফলাফল যোগ করুন", 18f, white, true))
        addPanel.addView(text("প্রকাশিত ফলাফল লিখুন। এই সংস্করণটি DKWin-এর সঙ্গে লাইভ সংযুক্ত নয়।", 12f, muted, false).apply { setPadding(0, 6, 0, 10) })
        roundInput = EditText(this).apply {
            hint = "রাউন্ড / PERIOD ID (ঐচ্ছিক)"
            setHintTextColor(muted); setTextColor(white); textSize = 14f
            setSingleLine(true); setPadding(12, 10, 12, 10)
            setBackgroundColor(Color.rgb(16, 11, 29))
        }
        addPanel.addView(roundInput, matchWrap())
        outcome = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("BIG", "SMALL"))
        }
        addPanel.addView(outcome, matchWrap())
        addPanel.addView(button("ফলাফল সংরক্ষণ", purple) { addResult() }, matchWrap())
        addPanel.addView(button("Floating AI আইকন চালু", cyan) { startOverlay() }, matchWrap())
        root.addView(addPanel)

        val historyPanel = panel()
        historyPanel.addView(text("PERIOD • ACTUAL • SIGNAL • RESULT", 15f, white, true))
        historyPanel.addView(text("সংকেতের কার্যকারিতা যাচাইয়ের জন্য নতুন রাউন্ডের ACTUAL ফলাফল যোগ করুন।", 12f, muted, false).apply { setPadding(0, 5, 0, 12) })
        historyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        historyPanel.addView(historyBox)
        historyPanel.addView(button("ইতিহাস মুছুন", Color.rgb(104, 43, 64)) {
            prefs.edit().remove("records").apply(); refresh()
        }, matchWrap())
        root.addView(historyPanel)

        val note = text("গুরুত্বপূর্ণ: এটি প্রাথমিক APK প্রজেক্ট। ভাসমান আইকন চালু করতে Android-এর অনুমতি লাগবে। স্ক্রিনের ছবি পড়া, লাইভ ডেটা/API এবং স্বয়ংক্রিয় ফলাফল সংগ্রহ এখনো যুক্ত নয়। BIG/SMALL ফলাফল নিশ্চিতভাবে অনুমান করা যায় না।", 11f, muted, false)
        note.setPadding(4, 14, 4, 0)
        root.addView(note)
    }

    private fun panel(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(15, 15, 15, 15)
        setBackgroundColor(card)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 14
        layoutParams = lp
    }
    private fun text(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }
    private fun button(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(if (color == cyan) bg else white)
        setBackgroundColor(color); textSize = 13f
        setOnClickListener { action() }
    }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 7 }

    private fun records(): JSONArray = try { JSONArray(prefs.getString("records", "[]")) } catch (_: Exception) { JSONArray() }
    private fun addResult() {
        val arr = records()
        val type = outcome.selectedItem.toString()
        val id = roundInput.text.toString().trim().ifBlank { "Manual-${arr.length() + 1}" }
        val obj = JSONObject().put("period", id).put("actual", type)
            .put("time", System.currentTimeMillis()).put("signal", "WAIT").put("result", "UNVERIFIED")
        arr.put(obj)
        prefs.edit().putString("records", arr.toString()).apply()
        roundInput.setText("")
        refresh()
    }

    private fun refresh() {
        val arr = records()
        var big = 0; var small = 0
        for (i in 0 until arr.length()) {
            if (arr.optJSONObject(i)?.optString("actual") == "BIG") big++ else small++
        }
        stats.text = "মোট ${arr.length()} • BIG $big • SMALL $small"
        signal.text = "WAIT"
        status.text = if (arr.length() < 10) "আরও ডেটা সংগ্রহ করুন • নিশ্চিত পূর্বাভাস নয়" else "ইতিহাসের অনুপাত দেখা যাচ্ছে; পরের ফল অজানা"
        historyBox.removeAllViews()
        if (arr.length() == 0) {
            historyBox.addView(text("এখনো কোনো ফলাফল নেই।", 12f, muted, false))
            return
        }
        for (i in arr.length() - 1 downTo maxOf(0, arr.length() - 20)) {
            val o = arr.optJSONObject(i) ?: continue
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(10, 9, 10, 9)
                setBackgroundColor(Color.rgb(17, 12, 29))
            }
            val date = SimpleDateFormat("dd MMM, HH:mm:ss", Locale.getDefault()).format(Date(o.optLong("time")))
            line.addView(text("${o.optString("period")}  •  ${o.optString("actual")}", 13f, white, true))
            line.addView(text("$date  •  SIGNAL: ${o.optString("signal")}  •  ${o.optString("result")}", 10f, muted, false))
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 6
            historyBox.addView(line, lp)
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "Zenova AI-এর জন্য 'Display over other apps' অনুমতি দিন, তারপর আবার চাপুন।", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Floating AI আইকন চালু হয়েছে", Toast.LENGTH_SHORT).show()
    }
}
