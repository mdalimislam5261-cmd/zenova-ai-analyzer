ZENOVA AI — Android Starter Project (বাংলা)
===========================================

এই ZIP-টি Android Studio/Gradle প্রজেক্টের সোর্স কোড। এটি APK ফাইল নয়।

বর্তমান ফিচার:
- ডার্ক বেগুনি/সায়ান Android UI
- হাতে PERIOD ও BIG/SMALL ফলাফল যোগ করা
- ফোনের SharedPreferences-এ ইতিহাস রাখা
- WAIT ডিফল্ট সিগন্যাল
- Android 'Display over other apps' অনুমতি পেলে ভাসমান Z আইকন

এখনো নেই:
- DKWin-এর লাইভ API/ডেটা সংযোগ
- স্বয়ংক্রিয় স্ক্রিন ক্যাপচার/OCR
- AI/ML মডেল ও ব্যাকএন্ড
- ২৪/৭ সার্ভার-সাইড সংগ্রহ
- নিশ্চিত পরবর্তী ফলাফল অনুমান

বিল্ড:
1. Android Studio-তে প্রজেক্ট ফোল্ডার খুলুন।
2. Gradle sync সম্পূর্ণ করুন (ইন্টারনেট লাগবে)।
3. Build > Build APK(s) নির্বাচন করুন।
4. সাধারণত APK থাকবে app/build/outputs/apk/debug/app-debug.apk

শুধু Termux দিয়ে:
- Termux-এ Gradle/Android SDK সেটআপ জটিল হতে পারে এবং সব ফোনে নির্ভরযোগ্য নয়।
- সহজ পদ্ধতি: Android Studio-সহ কম্পিউটার, অথবা GitHub Actions-এর মতো cloud build ব্যবহার করুন।
- APK ইনস্টল করার আগে Android-এর অনুমতি ও নিরাপত্তা সতর্কতা পড়ুন।

Floating icon:
- অ্যাপ খুলে 'Floating AI আইকন চালু' চাপুন।
- Android Settings-এ 'Display over other apps' অনুমতি দিন।
- অ্যাপে ফিরে আবার বোতাম চাপুন।
- আইকন চাপলে অ্যাপ খুলবে। এই সংস্করণ অন্য অ্যাপের স্ক্রিন পড়ে না।

নিরাপত্তা:
- DKWin-এর পাসওয়ার্ড, OTP বা কুকি অ্যাপে দেবেন না।
- কোনো সাইটের নিরাপত্তা এড়িয়ে ডেটা সংগ্রহ করবেন না।
- Big/Small ফলাফল অনিশ্চিত; অর্থনৈতিক সিদ্ধান্তের জন্য এই ডেমো ব্যবহার করবেন না।
